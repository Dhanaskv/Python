#!/usr/bin/python
set2={2000,2001,2002,2003,2004}
print(set2)
set2.remove(2000)
print(set2)
