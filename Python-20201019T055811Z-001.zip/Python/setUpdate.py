#!/usr/bin/python
parts={1,2,3,4,"apache"}
print(parts)
parts.update(["mysql","hello world","ascii"])
print(parts)
