#!/usr/bin/python
strIng='python single quotes'
print(strIng)
strIng1="python double quotes"
print(strIng1)
strIng2=''' triple Quotes are generally used for
    represent the multiline 
    or docstring'''
print(strIng2)

