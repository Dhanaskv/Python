#!/usr/bin/python
iter1=10
while(iter1<=100):
    print(iter1)
    iter1=iter1+1
    print(iter1)
print(iter1)    
