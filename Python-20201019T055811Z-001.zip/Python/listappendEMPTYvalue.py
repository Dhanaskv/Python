#!/usr/bin/python
l1=[]
l1.append(input("enter values:"))
print(l1)

