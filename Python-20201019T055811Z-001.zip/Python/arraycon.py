#!/usr/bin/python
import array as arr
a=arr.array('i',[1,2,3,4,5])
b=arr.array('i',[9,8,7,6,5])
a=b
print(a)
print(b)
c=arr.array('i')
c=a+b
print("array c=",c)

