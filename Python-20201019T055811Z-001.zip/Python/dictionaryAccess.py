#!/usr/bin/python
dict1={"num":"int","str":"python","max":100}
var=dict1["max"]
print(var)
