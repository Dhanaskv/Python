#!/usr/bin/python
Did1 = 21
Did2 = 5
Did3 = Did1 % Did2
print(Did3)
