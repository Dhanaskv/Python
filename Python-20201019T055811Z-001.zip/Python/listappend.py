#!/usr/bin/python
l1=[1,2,3,4,4.5]
n=input("append the total value:")

for var in range(0,n):
    l1.append(input("enter the value:"))

print(l1)

