#!/usr/bin/python
l1=[1,2,3,4]
l1.append(input("enter the value:"))

print(l1)
