#!/usr/bin/python
years={1990,1991,1992,1993,1994}
print(years)
print("print line by line")
for num in years:
    print(num)
