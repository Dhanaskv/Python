#!/usr/bin/python
VARi=0
while 1:
    print(VARi),
    VARi=VARi+1;
    if VARi == 10:
        break
print("came out of while loop");    
