#!/usr/bin/python
d1=100
d2=200
d3=250
if d1>d2 or d1>=d3:
    print("d1 is greater value");
elif d2>d1 or d2<=d3:
    print("d2 is greater value");
else:
    this is complicated;
