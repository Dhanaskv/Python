#!/usr/bin/python3
numVar3= input ("type first number: ")
numVar4=input ("type second number: ")
sum = numVar3 + numVar4

print("the sum is:",sum)
