#!/usr/bin/python
dic1={100:"int","python":"guido","float":4.5}
for n in dic1.values():
    print(n)
