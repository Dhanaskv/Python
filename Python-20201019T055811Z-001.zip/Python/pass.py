#!/usr/bin/python
for P in [0,1,2,3,4,5]:
    if(P == 4):
        pass
        print("this is pass block")
    print(P)
