#!/usr/bin/python
var={1,2,3,4,5,6}
print(var)
var.discard(9)
print(var)
