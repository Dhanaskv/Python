#!/usr/bin/python
List1=[1,3.5,"python"]
print(List1[0])
print(List1[1])
print(List1[-1])

