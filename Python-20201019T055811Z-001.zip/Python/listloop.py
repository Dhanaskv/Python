#!/usr/bin/python
l1=[1,5.6,"string"]
for var in l1:
    print(var)
