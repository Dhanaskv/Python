#!/usr/bin/python
t1=(1,2,3,4)
print(len(t1))
