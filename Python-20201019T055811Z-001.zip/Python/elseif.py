#!/usr/bin/python
ie1=input("The ie1 is : ");

if ie1>100 and ie1<=110:
     print("you are eligible");
elif ie1<150 and ie1>=140: 
     print("you are not eligible");
else:
     print("sorry to fail")
    

