#!/usr/bin/python
set1=set(["python","mutable","immutable"])
print(set1)
print("print line by line")
for set2 in set1:
    print(set2)
