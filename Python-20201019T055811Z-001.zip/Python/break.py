#!/usr/bin/python
Str="software"
for BRE in Str:
    if (BRE == 'a'):
        break
    print(BRE);
