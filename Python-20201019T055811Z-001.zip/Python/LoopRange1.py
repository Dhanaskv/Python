#!/usr/bin/python
newVAL=input("enter the number")
for lvar in range(10,newVAL,10):
      print(lvar)
