#!/usr/bin/python
set3={2000,2001,2002,2003}
print(set3)
set3.pop()
print(set3)

