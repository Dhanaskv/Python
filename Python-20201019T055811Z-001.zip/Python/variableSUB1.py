#!/usr/bin/python
subVar = 100
subVar2 = 20
subVar3 = 8
subVar4 = 5
subResult = subVar-subVar2-subVar3-subVar4
print(subResult)
