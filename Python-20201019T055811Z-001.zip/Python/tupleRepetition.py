#!/usr/bin/python
t1=(1,2,3,4,5)
print(t1*2)


