#!/usr/bin/python
iterate=1
while(iterate<10):
    print(iterate)
    iterate=iterate+1
