#!/usr/bin/python
tup1=(1,2,3,4,5,6)
tup2=(7,8,9)
print(tup1+tup2)
