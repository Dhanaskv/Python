#!/usr/bin/python
tup1=(10,20,"tnterpreter",50,"script")
print(tup1[-3])
print(tup1[-5:-1])
print(tup1[-3:-1])

