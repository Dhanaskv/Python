#!/usr/bin/python
stringVar="interpreter"
print(stringVar[-9:-1])
