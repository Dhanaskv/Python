#!/usr/bin/python
x=100
y=50
z=30
if x>y and x>z:
 print("x is biggest value");
if y>x and y>z:
 print("y is biggest value");
if z>x and z>y:
 print("z is biggest value");
