#!/usr/bin/python
t1=(1,2,3,4)
t2=(6,7,8,9)
print(cmp(t1,t2))
