#!/usr/bin/python
while 1:
    ig=1;
    while ig <= 10:
      print(ig);
      ig=ig+1
    newVar=int(input("enter the number: "))
    if newVar == 0:
         print("enter if break")
         break;
print("The while loop is complete");      

