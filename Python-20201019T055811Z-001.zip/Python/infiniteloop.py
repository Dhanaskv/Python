#!/usr/bin/python
while (1):
    print("infin")
