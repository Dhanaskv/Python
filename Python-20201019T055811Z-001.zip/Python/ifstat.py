#!/usr/bin/python
n=input("enter the number: ")
if n >= 2:
   print("The given statement is true")
