#!/usr/bin/python
nummul1 = 25
nummul2 = 25
nummul3 = nummul1 * nummul2
print(nummul3)

