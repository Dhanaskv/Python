#!/usr/bin/python
stringVAR="programmer"
for i in stringVAR:
    print(i);
    print("test");
