#!/usr/bin/python
tup1=(100,200,"python",400,"linux")
print(tup1[0:])
print(tup1[1:4])
print(tup1[:])
print(tup1[:3])

