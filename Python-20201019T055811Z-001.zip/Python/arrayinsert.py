#!/usr/bin/python
import array as arr
numbers = arr.array("i",[9,8,7,6,5,4,3,2,1])
numbers[0]=100
print(numbers)
