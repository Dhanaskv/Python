#!/usr/bin/python
import array as arc
an = arc.array("i",[1,2,3])
print("first element:", an[0])
print("Third element:", an[-1])
