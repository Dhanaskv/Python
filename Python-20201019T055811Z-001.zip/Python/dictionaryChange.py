#!/usr/bin/python
dic3={"h":1,"w":2,"a":3}
print(dic3)
dic3["a"]=100
print(dic3)
