#!/usr/bin/python
SubFloat1 = 12.123
SubFloat2 = 18.134
SubFloat3 = 19.156
SubResult = SubFloat1 - SubFloat2 - SubFloat3
print(SubResult)
