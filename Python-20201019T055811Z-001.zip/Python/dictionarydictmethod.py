#!/usr/bin/python
dict1={}
print("Empty dictionary")
print(dict1)

dict2=dict({1:2,3:4,5:6})
print(dict2)

dict3=dict({(1,2),(3,4)})
print(dict3)
