#!/usr/bin/python
dic1={"brand":"ford","year":70,"design":"altro"}
dic1.pop("year")
print(dic1)


