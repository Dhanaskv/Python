#!/usr/bin/python
strING = "programmer"
print(strING[1:5])
