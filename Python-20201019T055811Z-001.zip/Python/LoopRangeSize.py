#!/usr/bin/python
varNum=input("enter the number: ")

for sizeVar in range(1,10):

    newval=varNum*sizeVar

    print(varNum,"*",sizeVar,'=',newval)
