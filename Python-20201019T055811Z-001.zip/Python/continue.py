#!/usr/bin/python
var=0
while(var<10):
    var=var+1
    if(var == 8):
        continue
    print(var);
print("loop completed");   

Var=1
while(Var<4):
    Var=Var+1
    if(Var == 5):
        break
    print(Var);
print("the second while is completed");    
