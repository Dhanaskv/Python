#!/usr/bin/python
dic1={1:2,3:4,5:6}
for var in dic1:
    print(var)


