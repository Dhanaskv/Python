#!/usr/bin/python3
numRange=input("enter the number: ")
for ranVar in range(1,20):
    c=numRange*ranVar
    print(numRange,"*","ranVar","=",c) 
