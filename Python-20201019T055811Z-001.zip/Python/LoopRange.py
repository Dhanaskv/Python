#!/usr/bin/python

for rangeVal in range(10):
    print(rangeVal)

