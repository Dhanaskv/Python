#!/usr/bin/python
dic={"name":"x","subject":"python"}
var=dic.get("name")
print(var)

