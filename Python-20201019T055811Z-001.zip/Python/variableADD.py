#!/usr/bin/python
numVar1=100
numVar2=200
numVaradd=(numVar1+numVar2)
print(numVaradd)
