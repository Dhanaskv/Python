#!/usr/bin/python
numVarn1 = 5
numVarn2 = 2
numVarn3 = numVarn1 - numVarn2
print  (numVarn3)
