#!/usr/bin/python
dic1={1:2,3:4,5:6}
for x in dic1.items():
    print(x)
