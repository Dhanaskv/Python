#!/usr/bin/python
list2=["data",9.8,"script"]
print(list2)
list2[0]="python"
print(list2)

