#!/usr/bin/python
computers={"python","java","linux","unix"}
print(computers)
computers.add("program")
computers.add("linus")
print(computers)
