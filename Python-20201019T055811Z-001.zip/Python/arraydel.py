#!/usr/bin/python
import array as arr
num = arr.array("i",[1,2,3,4,5,6,6])
del num[5]
print(num)
