#!/usr/bin/python
import array as arr
a=arr.array('i',[1,2,3,4,5,6,7])
a[1]=0
print(a)
