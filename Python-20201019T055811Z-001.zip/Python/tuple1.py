#!/usr/bin/python
tup1=(10,20,30,40,50,60)
print(tup1[0])
print(tup1[1])
print(tup1[2])
print(tup1[3])
for i in tup1:
    print(i)

