#!/usr/bin/python
list2=[1]
n=input("enter the append total value:")

for var in range(0,n):
    list2.append(input("enter the value:"))

print(list2) 
