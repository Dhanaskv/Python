#!/usr/bin/python
import array as arr
a = arr.array("i",[1,2,3,4,5,6,7,8,9])

for var in range(0,8):
    print("The first created array is :",a[var])

b=arr.array("d",[1.2,3.4,5.6])

for vaR in range(0,2):
    print("the second array is:",b[vaR])
