#!/usr/bin/python
if (0):
    print("this is true")
n=10
if (n>=100):
    print("this is second")
else: 
    print("not equal")


