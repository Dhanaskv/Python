#!/usr/bin/python
Var=input("enter the Var number:");
Var1=input("enter the Var1 number:");
Var2=input("enter the Var2 number:");

if Var>Var1 and Var>Var2:
    print("Var is biggest value");
if Var1>Var and Var1>Var2:
    print("Var1 is biggest value");
if Var2>Var and Var2>Var1:
    print("Var2 is biggest value");
