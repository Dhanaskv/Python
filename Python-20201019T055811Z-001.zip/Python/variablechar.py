#!/usr/bin/python
a = 'x'

print(a)

        
