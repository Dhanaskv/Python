#!/usr/bin/python
Dictionary={"computer":"west","arch":86,100:120}
print(type(Dictionary))
print(Dictionary)
